from math import erf, sqrt, pi, exp
from scipy import integrate


# нормальное распределение функции
def f_norm(x, mu=0, s=1):
    return (1+erf((x-mu)/sqrt(2)/s))/2

# нормальное распределение плотность
def rho_norm(x, mu=0,s=1):
    return 1/sqrt(2*pi*s)*exp(-(x-mu)**2/2/s**2)

# вероятность ошибки первого рода
def p_value(x, mu=0, s=1):
    return 2*(1-f_norm(x,mu,s)) if x >= mu else 2*f_norm(x,mu,s)

# Обратная функция распределения
def inv_f_norm(p, mu, s, t=0.001):
    if mu != 0 or s != 1:
        return mu + s * inv_f_norm(p, 0, 1, t)
    low_x, low_p = -100, 0
    hi_x, hi_p = 100, 1
    while hi_x - low_x > t:
        mid_x = (low_x + hi_x) / 2
        mid_p = f_norm(mid_x)
        if mid_p < p:
            low_x, low_p = mid_x, mid_p
        elif mid_p > p:
            hi_x, hi_p = mid_x, mid_p
        else:
            break
    return mid_x

def first_task():
    # кол-во плиток
    x = 500 / 8
    alpha = 0.05
    beta = 0.8
    for n in range(100, 10000):
        p0 = 3/8
        pa = 4/8

        mu0 = n * p0
        muA = n * pa

        # нахожу стандартное отклонение
        sigma0 = sqrt(n * p0 * (1 - p0))
        sigmaA = sqrt(n * pa * (1 - pa))
        # нахожу нижнюю и верхнюю критическую точку
        p_low = inv_f_norm(alpha / 2, mu0, sigma0)
        p_high = 2 * mu0 - p_low

        P_value = p_value(x, mu0, sigma0)

        power = 1 - (integrate.quad(rho_norm, p_low, p_high, args=(muA, sigmaA)))[0]
        if P_value > alpha and power > beta:
            print(f"Мощность проверки равна {power}")
            print(n)
            break

first_task()


